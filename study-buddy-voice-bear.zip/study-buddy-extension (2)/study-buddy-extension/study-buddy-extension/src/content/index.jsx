import React from 'react';
import { createRoot } from 'react-dom/client';
import StudyBuddy from './StudyBuddy';
import { initDyslexiaMode } from "./dyslexiaMode";

// Initialize everything
const init = () => {
  // ✅ Initialize dyslexia mode FIRST
  initDyslexiaMode();

  // Prevent duplicate injection
  if (document.getElementById('study-buddy-root')) {
    return;
  }

  // Create container for Study Buddy
  const rootElement = document.createElement('div');
  rootElement.id = 'study-buddy-root';

  document.body.appendChild(rootElement);

  // Render React component
  const root = createRoot(rootElement);
  root.render(<StudyBuddy />);
};

// Wait until DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
