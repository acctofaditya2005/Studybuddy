import React, { useEffect } from "react";
import FixedSmartOwl from "../components/FixedSmartOwl";

const DYSLEXIA_CLASS = "sb-dyslexia-enabled";
const STYLE_ID = "sb-dyslexia-style";
const EVENT_NAME = "sb:toggle-dyslexia";

function ensureDyslexiaStyleInjected() {
  if (document.getElementById(STYLE_ID)) return;

  const style = document.createElement("style");
  style.id = STYLE_ID;

  const fontUrl = chrome.runtime.getURL("fonts/OpenDyslexic-Regular.otf");

  style.textContent = `
    @font-face {
      font-family: "OpenDyslexic";
      src: url("${fontUrl}") format("opentype");
      font-weight: normal;
      font-style: normal;
    }

    body.${DYSLEXIA_CLASS},
    body.${DYSLEXIA_CLASS} * {
      font-family: "OpenDyslexic", Arial !important;
      letter-spacing: 0.12em !important;
      line-height: 1.6 !important;
    }
  `;

  (document.head || document.documentElement).appendChild(style);
}

function toggleDyslexiaNow() {
  ensureDyslexiaStyleInjected();
  document.body.classList.toggle(DYSLEXIA_CLASS);
  console.log(
    "[StudyBuddy] Dyslexia mode:",
    document.body.classList.contains(DYSLEXIA_CLASS)
  );
}

const StudyBuddy = () => {
  useEffect(() => {
    console.log("StudyBuddy content script loaded");

    // Ensure style exists early (optional, but helps on first toggle)
    ensureDyslexiaStyleInjected();

    // 1) Listen for messages (popup / background)
    const onMessage = (request) => {
      // accept both names since your UI logs "dyslexic-font"
      if (request?.action === "toggleDyslexia" || request?.action === "dyslexic-font") {
        console.log("[StudyBuddy] Message toggle request:", request);
        toggleDyslexiaNow();
      }
    };
    chrome.runtime.onMessage.addListener(onMessage);

    // 2) Listen for in-page UI event (your Settings panel button)
    const onEvent = () => {
      console.log("[StudyBuddy] Event toggle request:", EVENT_NAME);
      toggleDyslexiaNow();
    };
    window.addEventListener(EVENT_NAME, onEvent);

    // 3) Optional: expose a global function for quick testing
    window.__SB_toggleDyslexia = toggleDyslexiaNow;

    return () => {
      chrome.runtime.onMessage.removeListener(onMessage);
      window.removeEventListener(EVENT_NAME, onEvent);
      // (don’t delete window.__SB_toggleDyslexia; harmless)
    };
  }, []);

  return (
    <>
      <FixedSmartOwl />
    </>
  );
};

export default StudyBuddy;
