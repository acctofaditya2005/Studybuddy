import React from "react";

const Popup = () => {

  const toggleDyslexia = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return;

      chrome.tabs.sendMessage(tabs[0].id, {
        action: "toggleDyslexia"
      });
    });
  };

  return (
    <div style={{ padding: "10px", width: "200px" }}>
      <button
        onClick={toggleDyslexia}
        style={{
          width: "100%",
          padding: "8px",
          borderRadius: "6px",
          border: "none",
          background: "#667eea",
          color: "white",
          fontWeight: "600",
          cursor: "pointer"
        }}
      >
        Toggle Dyslexia Mode
      </button>
    </div>
  );
};

export default Popup;
