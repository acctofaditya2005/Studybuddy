import React, { useState, useEffect } from 'react';

const Popup = () => {
  const [apiKey, setApiKey] = useState('');
  const [saved, setSaved] = useState(false);
  const [summaries, setSummaries] = useState([]);
  const [activeTab, setActiveTab] = useState('settings');

  // ✅ NEW: Dyslexia toggle state
  const [dyslexiaEnabled, setDyslexiaEnabled] = useState(false);

  // ✅ Send toggle message to active tab
  async function sendToggleToActiveTab(enabled) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, { action: "toggleDyslexia", enabled });
    }
  }

  useEffect(() => {
    // Load API key
    chrome.storage.sync.get(['geminiApiKey'], (result) => {
      if (result.geminiApiKey) {
        setApiKey(result.geminiApiKey);
      }
    });

    // ✅ Load dyslexia setting
    chrome.storage.sync.get(['dyslexiaEnabled'], (result) => {
      setDyslexiaEnabled(!!result.dyslexiaEnabled);
    });

    loadSummaries();
  }, []);

  const loadSummaries = async () => {
    const response = await chrome.runtime.sendMessage({ action: 'getSummaries' });
    setSummaries(response?.summaries || []);
  };

  const handleSaveApiKey = () => {
    chrome.storage.sync.set({ geminiApiKey: apiKey }, () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    });
  };

  // ✅ Handle dyslexia toggle
  const handleDyslexiaToggle = async (e) => {
    const enabled = e.target.checked;
    setDyslexiaEnabled(enabled);

    await chrome.storage.sync.set({ dyslexiaEnabled: enabled });
    await sendToggleToActiveTab(enabled);
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <div style={{
      width: '100%',
      minHeight: '400px',
      background: 'white'
    }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        padding: '20px',
        textAlign: 'center'
      }}>
        <div style={{ fontSize: '40px', marginBottom: '10px' }}>🦉</div>
        <h1 style={{ margin: '0 0 5px 0', fontSize: '20px', fontWeight: '600' }}>
          Study Buddy
        </h1>
        <p style={{ margin: 0, fontSize: '13px', opacity: 0.9 }}>
          Your AI Reading Companion
        </p>
      </div>

      {/* Tabs */}
      <div style={{
        display: 'flex',
        borderBottom: '1px solid #e0e0e0',
        background: '#f9f9f9'
      }}>
        <button
          onClick={() => setActiveTab('settings')}
          style={{
            flex: 1,
            padding: '12px',
            border: 'none',
            background: activeTab === 'settings' ? 'white' : 'transparent',
            borderBottom: activeTab === 'settings' ? '2px solid #667eea' : 'none',
            cursor: 'pointer',
            fontWeight: activeTab === 'settings' ? '600' : 'normal',
            color: activeTab === 'settings' ? '#667eea' : '#666'
          }}
        >
          Settings
        </button>
        <button
          onClick={() => {
            setActiveTab('summaries');
            loadSummaries();
          }}
          style={{
            flex: 1,
            padding: '12px',
            border: 'none',
            background: activeTab === 'summaries' ? 'white' : 'transparent',
            borderBottom: activeTab === 'summaries' ? '2px solid #667eea' : 'none',
            cursor: 'pointer',
            fontWeight: activeTab === 'summaries' ? '600' : 'normal',
            color: activeTab === 'summaries' ? '#667eea' : '#666'
          }}
        >
          Saved ({summaries.length})
        </button>
      </div>

      {/* Content */}
      <div style={{ padding: '20px' }}>
        {activeTab === 'settings' && (
          <div>

            {/* API KEY SECTION */}
            <div style={{ marginBottom: '15px' }}>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                fontSize: '14px',
                color: '#333'
              }}>
                Google Gemini API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Enter your API key..."
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ddd',
                  borderRadius: '6px',
                  fontSize: '14px',
                  boxSizing: 'border-box'
                }}
              />
            </div>

            <button
              onClick={handleSaveApiKey}
              style={{
                width: '100%',
                padding: '12px',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                marginBottom: '20px'
              }}
            >
              {saved ? '✓ Saved!' : 'Save API Key'}
            </button>

            {/* ✅ NEW DYSLEXIA TOGGLE SECTION */}
            <div style={{
              background: '#f0f7ff',
              border: '1px solid #cce5ff',
              borderRadius: '6px',
              padding: '15px',
              marginBottom: '20px'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '14px' }}>
                    Dyslexia Mode
                  </div>
                  <div style={{ fontSize: '12px', color: '#666' }}>
                    OpenDyslexic font + improved spacing
                  </div>
                </div>

                <input
                  type="checkbox"
                  checked={dyslexiaEnabled}
                  onChange={handleDyslexiaToggle}
                  style={{ transform: 'scale(1.2)' }}
                />
              </div>
            </div>

            {/* HOW TO USE */}
            <div style={{
              marginTop: '10px',
              padding: '15px',
              background: '#fff9e6',
              borderRadius: '6px',
              fontSize: '13px'
            }}>
              <strong>🦉 How to use:</strong>
              <ul style={{ margin: '10px 0 0 0', paddingLeft: '20px' }}>
                <li>The owl appears on every webpage</li>
                <li>Drag it anywhere you want</li>
                <li>Click the 📝 button to summarize</li>
                <li>Click the owl to chat about the page</li>
                <li>Use Dyslexia Mode if helpful</li>
              </ul>
            </div>

          </div>
        )}

        {activeTab === 'summaries' && (
          <div>
            {summaries.length === 0 ? (
              <div style={{
                textAlign: 'center',
                padding: '40px 20px',
                color: '#999'
              }}>
                <div style={{ fontSize: '48px', marginBottom: '10px' }}>📚</div>
                <p>No saved summaries yet!</p>
              </div>
            ) : (
              <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                {summaries.map((item, idx) => (
                  <div
                    key={idx}
                    style={{
                      marginBottom: '15px',
                      padding: '12px',
                      background: '#f9f9f9',
                      borderRadius: '6px',
                      fontSize: '13px',
                      borderLeft: '3px solid #667eea'
                    }}
                  >
                    <div style={{ fontWeight: '600', marginBottom: '5px' }}>
                      {item.title}
                    </div>
                    <div style={{ fontSize: '12px', color: '#666', marginBottom: '8px' }}>
                      {formatDate(item.timestamp)}
                    </div>
                    <div style={{ color: '#555', marginBottom: '8px' }}>
                      {item.summary.slice(0, 150)}...
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Popup;
