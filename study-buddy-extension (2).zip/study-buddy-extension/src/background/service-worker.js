// Background service worker - handles API calls to Google Gemini

const GEMINI_API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent';
// Get API key from storage
async function getApiKey() {
  const result = await chrome.storage.sync.get(['geminiApiKey']);
  return result.geminiApiKey || '';
}

// Call Google Gemini API
async function callGemini(prompt, apiKey) {
  if (!apiKey) {
    throw new Error('API key not set. Please add your Gemini API key in the extension popup.');
  }

  const response = await fetch(`${GEMINI_API_ENDPOINT}?key=${apiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{
        parts: [{
          text: prompt
        }]
      }],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 1024,
      }
    })
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`API Error: ${error}`);
  }

  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}

// Handle summarization
async function handleSummarize(pageContent, language) {
  const apiKey = await getApiKey();
  
  const prompt = `You are a concise study assistant. Create a brief, scannable summary of this webpage.

RULES:
- Maximum 150 words
- Use 3-5 bullet points
- Focus on KEY facts and main ideas only
- Skip introductions and filler
- Use simple, clear language
- Write in ${language}

Content:
${pageContent}

Summary in ${language}:`;

  const summary = await callGemini(prompt, apiKey);
  return { summary };
}

// Handle chat
async function handleChat(message, pageContent, language, conversationHistory) {
  const apiKey = await getApiKey();
  
  // Build conversation context - keep last 8 messages
  const recentHistory = conversationHistory.slice(-8);
  let conversationText = recentHistory
    .map(msg => `${msg.role === 'user' ? 'Student' : 'Assistant'}: ${msg.content}`)
    .join('\n');

  const prompt = `You are Study Buddy, a helpful AI tutor. Answer the student's question clearly and concisely in ${language}.

Context from webpage: ${pageContent.slice(0, 800)}

Previous conversation:
${conversationText}

Student's question: ${message}

Your answer in ${language}:`;

  const reply = await callGemini(prompt, apiKey);
  
  // Make sure we have a valid response
  if (!reply || reply.trim().length < 2) {
    throw new Error('Empty response received');
  }
  
  return { reply: reply.trim() };
}

// AWS API Configuration
const AWS_API_BASE = 'https://f3a0j5vbp3.execute-api.us-east-1.amazonaws.com/prod';

// Get or create unique user ID for this extension installation
async function getUserID() {
  const result = await chrome.storage.local.get(['userID']);
  if (result.userID) {
    return result.userID;
  }
  
  // Generate new unique ID
  const newUserID = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  await chrome.storage.local.set({ userID: newUserID });
  return newUserID;
}

// Save summary to AWS
async function saveSummary(summary, url, title, type = 'summary') {
  try {
    const userID = await getUserID();
    
    const data = {
      userID: userID,
      type: type,
      content: summary,
      pageUrl: url,
      pageTitle: title
    };
    
    const response = await fetch(`${AWS_API_BASE}/save`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    
    const result = await response.json();
    
    if (response.ok) {
      return { success: true, timestamp: result.timestamp };
    } else {
      throw new Error(result.error || 'Failed to save');
    }
  } catch (error) {
    console.error('Error saving to AWS:', error);
    return { success: false, error: error.message };
  }
}

// Get saved summaries from AWS
async function getSummaries() {
  try {
    const userID = await getUserID();
    
    const response = await fetch(`${AWS_API_BASE}/history?userID=${userID}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const result = await response.json();
    
    if (response.ok) {
      // Transform AWS data format to match what the popup expects
      const summaries = result.items.map(item => ({
        summary: item.content,
        url: item.pageUrl,
        title: item.pageTitle,
        timestamp: new Date(item.timestamp).toISOString(),
        type: item.type || 'summary'
      }));
      
      return { summaries };
    } else {
      throw new Error(result.error || 'Failed to fetch');
    }
  } catch (error) {
    console.error('Error fetching from AWS:', error);
    return { summaries: [] };
  }
}

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    try {
      let response;

      switch (request.action) {
        case 'summarize':
          response = await handleSummarize(request.pageContent, request.language);
          break;

        case 'chat':
          response = await handleChat(
            request.message,
            request.pageContent,
            request.language,
            request.conversationHistory
          );
          break;

        case 'saveSummary':
          response = await saveSummary(
            request.summary,
            request.url,
            request.title,
            request.type || 'summary'
          );
          break;

        case 'getSummaries':
          response = await getSummaries();
          break;

        default:
          response = { error: 'Unknown action' };
      }

      sendResponse(response);
    } catch (error) {
      console.error('Background script error:', error);
      sendResponse({ error: error.message });
    }
  })();

  return true; // Keep message channel open for async response
});

console.log('Study Buddy background service worker loaded!');
