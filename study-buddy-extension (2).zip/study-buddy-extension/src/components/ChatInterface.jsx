import React, { useState, useRef, useEffect } from 'react';

const ChatInterface = ({ onClose, pageContent, language, initialSummary = null }) => {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi! I can help you understand this page. Ask me anything!' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [summaryAdded, setSummaryAdded] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Add summary when it arrives (even if chat was already open)
  useEffect(() => {
    if (initialSummary && !summaryAdded) {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `📝 Summary:\n\n${initialSummary}` 
      }]);
      setSummaryAdded(true);
    }
  }, [initialSummary, summaryAdded]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    const updatedMessages = [...messages, { role: 'user', content: userMessage }];
    setMessages(updatedMessages);
    setIsLoading(true);

    try {
      // Send message to background script
      const response = await chrome.runtime.sendMessage({
        action: 'chat',
        message: userMessage,
        pageContent: pageContent,
        language: language,
        conversationHistory: updatedMessages
      });

      if (!response.reply || response.reply.trim().length === 0) {
        throw new Error('Empty response from AI');
      }

      const finalMessages = [...updatedMessages, { role: 'assistant', content: response.reply }];
      setMessages(finalMessages);
      
      // Auto-save chat after each exchange (in background)
      chrome.runtime.sendMessage({
        action: 'saveSummary',
        summary: finalMessages.map(m => `${m.role === 'user' ? 'You' : 'Study Buddy'}: ${m.content}`).join('\n\n'),
        url: window.location.href,
        title: document.title,
        type: 'chat'
      }).catch(err => console.error('Auto-save failed:', err));
      
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Sorry, I encountered an error. Please try again or check your API key.' 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div style={{
      width: '350px',
      height: '450px',
      background: 'white',
      borderRadius: '15px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        padding: '15px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h3 style={{ margin: 0, fontSize: '16px', fontWeight: '600' }}>
          Study Buddy Chat
        </h3>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={async () => {
              // Allow user to name/organize this chat
              const customTitle = prompt('Give this chat a custom name:', document.title);
              if (!customTitle) return;
              
              try {
                await chrome.runtime.sendMessage({
                  action: 'saveSummary',
                  summary: messages.map(m => `${m.role === 'user' ? 'You' : 'Study Buddy'}: ${m.content}`).join('\n\n'),
                  url: window.location.href,
                  title: customTitle,  // Use custom title
                  type: 'chat'
                });
                alert(`💾 Chat saved as "${customTitle}"!`);
              } catch (error) {
                console.error('Error saving chat:', error);
              }
            }}
            style={{
              background: 'rgba(255,255,255,0.2)',
              border: 'none',
              color: 'white',
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              cursor: 'pointer',
              fontSize: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
            title="Name and save this chat"
          >
            +
          </button>
          <button
            onClick={onClose}
            style={{
              background: 'rgba(255,255,255,0.2)',
              border: 'none',
              color: 'white',
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              cursor: 'pointer',
              fontSize: '18px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            ×
          </button>
        </div>
      </div>

      {/* Messages */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '15px',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px'
      }}>
        {messages.map((msg, idx) => (
          <div
            key={idx}
            style={{
              alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start',
              maxWidth: '80%'
            }}
          >
            <div style={{
              background: msg.role === 'user' 
                ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                : '#f0f0f0',
              color: msg.role === 'user' ? 'white' : '#333',
              padding: '10px 14px',
              borderRadius: msg.role === 'user' 
                ? '15px 15px 5px 15px'
                : '15px 15px 15px 5px',
              fontSize: '14px',
              lineHeight: '1.4',
              wordWrap: 'break-word'
            }}>
              {msg.content}
            </div>
          </div>
        ))}
        {isLoading && (
          <div style={{ alignSelf: 'flex-start' }}>
            <div style={{
              background: '#f0f0f0',
              padding: '10px 14px',
              borderRadius: '15px 15px 15px 5px',
              fontSize: '14px'
            }}>
              <span className="typing-indicator">●●●</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div style={{
        padding: '15px',
        borderTop: '1px solid #e0e0e0',
        display: 'flex',
        gap: '10px'
      }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask me anything about this page..."
          disabled={isLoading}
          style={{
            flex: 1,
            padding: '10px 14px',
            border: '1px solid #ddd',
            borderRadius: '20px',
            fontSize: '14px',
            outline: 'none',
            fontFamily: 'inherit'
          }}
        />
        <button
          onClick={handleSend}
          disabled={isLoading || !input.trim()}
          style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            border: 'none',
            borderRadius: '50%',
            width: '40px',
            height: '40px',
            cursor: isLoading || !input.trim() ? 'not-allowed' : 'pointer',
            fontSize: '18px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            opacity: isLoading || !input.trim() ? 0.5 : 1
          }}
        >
          ➤
        </button>
      </div>

      <style>{`
        .typing-indicator {
          display: inline-block;
          animation: typing 1.4s infinite;
        }
        @keyframes typing {
          0%, 60%, 100% { opacity: 0.3; }
          30% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default ChatInterface;
